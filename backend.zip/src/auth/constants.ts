export const jwtConstants = {
  secret: 'fanscrmsecuritytoken',
};
